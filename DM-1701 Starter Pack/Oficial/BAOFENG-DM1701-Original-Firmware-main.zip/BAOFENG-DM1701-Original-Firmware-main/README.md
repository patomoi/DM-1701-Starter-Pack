这是我个人保存的宝峰DM1701官方固件，官方刷写固件软件。
固件分为有CSV联系人版本和没有CSV联系人版本。
from BG7QVB

——————————————我是分割线—————————————

Firmware Update Operation:

⦁	Install the firmware update program with the file “DMR Firmware Download(User English) Setup v3.06’’ and run the program.

⦁	Connect the radio to the computer with the programming cable, press and hold PTT + SK1 when turn on the radio, the radio will go into update mode and the Rx/Tx signal light will flash green and red.

⦁	Click “Open file upgrade’’ and select the firmware file DM-1701(CSV)-V02.02.bin, then “Download file of upgrade”.

⦁	After it shows ‘’Download upgrade file successful’’, reboot the radio and the update is finished.
